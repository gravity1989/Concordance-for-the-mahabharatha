#include<iostream>
#include<fstream>
#include<string.h>
#include<conio.h>

using namespace std;

typedef struct hash_table
{
    char word[60];
    struct hash_table *next;
}hashing;

hashing *hash[19][360][250];
char dictionary[170000][60];
char cleaned_dict[170000][60];
int no_words = 0,cleaned = 0;

void initialize()
{
    for(int i = 0; i < 19; i++)
            for(int j = 0; j < 360; j++)
                    for(int k = 0; k < 250; k++)
                            hash[i][j][k] = NULL;
}

void insert_into_hash(char word[],int buk,int chap,int lin)
{
     hashing *new_word,*temp,*prev = NULL;
     new_word = (hashing*)malloc(sizeof(hashing));
     strcpy(new_word->word,word);
     new_word->next = NULL;
     if(hash[buk][chap][lin] == NULL)
     {
                             hash[buk][chap][lin] = new_word;
                             cout<<"inserted "<< hash[buk][chap][lin]->word<<" "<<buk<<"."<<chap<<"."<<lin<<endl;
                             return;
     }
     temp = hash[buk][chap][lin];
     while(temp != NULL)
     {
                prev = temp;
                temp = temp->next;
     }
     prev->next = new_word;
     return;
}

void cleaning ()
{
     hashing *temp;
     int i,j,k,w = 0,write = 0,flag = 0,c = 0;

     while(w<no_words)
     {
                      flag = 0;
                      for(i=1;i<19&&flag==0;i++)
                                                for(j=1;j<360&&flag==0;j++)
                                                                           for(k=1;k<250&&flag==0;k++)
                                                                           {
                                                                                                      temp = hash[i][j][k];
                                                                                                      while(temp!=NULL && strcmp(temp->word,dictionary[w])!=0)
                                                                                                      {
                                                                                                                       temp = temp->next;
                                                                                                      }
                                                                                                      if(temp!=NULL)                                                                                        
                                                                                                      flag = 1;
                                                                           }
                                                                           if(flag)
                                                                           {
                                                                                   cout<<dictionary[w]<<endl;
                                                                                   strcpy(cleaned_dict[c++],dictionary[w]);
                                                                           }
                      w++;
     }
     cleaned = c;    
}

void display ()
{
     hashing *temp;
     int i,j,k,w = 0,write = 0;
     ofstream out;

     out.open("concordance.txt",ios::out);
     while(w<cleaned)
     {
                     out<<cleaned_dict[w]<<" ";
                     for(i=1;i<19;i++)
                                      for(j=1;j<360;j++)
                                                        for(k=1;k<250;k++)
                                                        {
                                                                          temp = hash[i][j][k];
                                                                          while(temp!=NULL && strcmp(temp->word,cleaned_dict[w])!=0)
                                                                          {
                                                                                           temp = temp->next;
                                                                          }
                                                                          if(temp!=NULL)
                                                                                        out<<i<<"."<<j<<"."<<k<<", ";
                                                        }
                     out<<endl;
                     w++;
     }
     out.close();
}

int main ()
{
    int chap,lin,buk,count = 0,w = 0;
    int i,j,k;
    char *begin;
    char book[3],chapter[4],line[4],file[18][15],buf[500];
    ifstream in2;
    ofstream out;
    struct hash_table *temp = NULL;

    initialize();

    in2.open("dictionary_monier.txt",ios::in);
    while(!in2.eof())
    {
                     in2 >> dictionary[w++];
    }
    in2.close();
    no_words = w;
    cout<<no_words<<endl;
    strcpy(file[0],"MBh01.txt");
    strcpy(file[1],"MBh02.txt");
    strcpy(file[2],"MBh03.txt");
    strcpy(file[3],"MBh04.txt");
    strcpy(file[4],"MBh05.txt");
    strcpy(file[5],"MBh06.txt");
    strcpy(file[6],"MBh07.txt");
    strcpy(file[7],"MBh08.txt");
    strcpy(file[8],"MBh09.txt");
    strcpy(file[9],"MBh10.txt");
    strcpy(file[10],"MBh11.txt");
    strcpy(file[11],"MBh12.txt");
    strcpy(file[12],"MBh13.txt");
    strcpy(file[13],"MBh14.txt");
    strcpy(file[14],"MBh15.txt");
    strcpy(file[15],"MBh16.txt");
    strcpy(file[16],"MBh17.txt");
    strcpy(file[17],"MBh18.txt");
    

    for(int i = 0 ; i < 18; i++)
    {
            ifstream in1;
            /*if(i<10)
            {
                    sprintf(file,"MBh0%d.txt",i);
                    cout<<file<<endl;
            }
            else
            {
                    sprintf(file,"MBh%d.txt",i);
                    cout<<file<<endl;
            }*/
            in1.open(file[i],ios::in);
            if(in1.eof())
                          cout<<"end of file\n";
            else
            while(!in1.eof())
            {
                             in1.getline(buf,sizeof(buf));
                             if(buf[0] == '1' || buf[0] == '0')
                             {
                                       book[0] = buf[0];
                                       book[1] = buf[1];
                                       book[2] = '\0';
                                       chapter[0] = buf[2];
                                       chapter[1] = buf[3];
                                       chapter[2] = buf[4];
                                       chapter[3] = '\0';
                                       line[0] = buf[5];
                                       line[1] = buf[6];
                                       line[2] = buf[7];
                                       line[3] = '\0';
                                       sscanf(book,"%d",&buk);
                                       sscanf(chapter,"%d",&chap);
                                       sscanf(line,"%d",&lin);
                                       
                                       w = 0;
                                       while(w < no_words)
                                       {
                                               if(strlen(dictionary[w])>5)
                                               {		
                                                    if(strstr(buf,dictionary[w]))
                                                    {
                                                                                 insert_into_hash(dictionary[w],buk,chap,lin);
                                                    }
                                               }
                                               w++;
                                       }
                             }
            }
            in1.close();
    }
    cout<<"cleaning\n";
    cleaning();
    cout<<"printing\n";
    display();
    //getch();
    return 0;
}
